console.log("Si funciona el JS")

let selectorCategoria = ""
let actualYear = 2022

function myFunction() {

    let nombreUsuario = prompt( "Bienvenido humano, ingrese su nombre" )

    let saludoHumano = alert( "Ahora si. Hola" + " " + nombreUsuario[0].toUpperCase() + nombreUsuario.substring(1) + "\nAcepta para continuar")

    selectorCategoria = prompt( "Ingrese si desea seguro para auto o casa" )

    selectorCategoria = selectorCategoria.toLowerCase()

    selector1()

    selector2()
}


function selector1() {
    if (selectorCategoria === "casa") {
        prompt("Elegiste casa");
    } 
    else if (selectorCategoria === "auto") {
        prompt("Elegiste auto");
    }
    else { 
        alert("Debes elegir auto o casa")
    }
}

function selector2() {
    let inputYear = prompt("Ingrese el año de su vehiculo");
    let year = Number(inputYear)
    while (year === false) {
        alert("Ingresa correctamente el año, tiene que ser un numero")
        inputYear = prompt("Ingrese el año de su vehiculo");
        year = Number(inputYear)
    }

    alert("Su auto tiene " + (actualYear - inputYear) + " años" + "\nAcepta para continuar") 

}

